package com.example.teledoctor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
